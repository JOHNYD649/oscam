#ifndef READER_NAGRACAK7_H_
#define READER_NAGRACAK7_H_

void CAK7_getCamKey(struct s_reader *reader);

#endif
