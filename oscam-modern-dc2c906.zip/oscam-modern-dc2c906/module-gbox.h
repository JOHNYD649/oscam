#ifndef MODULE_GBOX_H_
#define MODULE_GBOX_H_

// Parsing function used in oscam-config-reader.c
void mgencrypted_fn(const char *token, char *value, void *setting, FILE *f);

#endif
