#ifndef READERS_H_
#define READERS_H_

void reader_nagra(struct s_cardsystem *);
void reader_irdeto(struct s_cardsystem *);
void reader_cryptoworks(struct s_cardsystem *);
void reader_viaccess(struct s_cardsystem *);
void reader_conax(struct s_cardsystem *);
void reader_seca(struct s_cardsystem *);
void reader_videoguard1(struct s_cardsystem *);
void reader_videoguard2(struct s_cardsystem *);
void reader_videoguard12(struct s_cardsystem *);
void reader_dre(struct s_cardsystem *);
void reader_tongfang(struct s_cardsystem *);
void reader_bulcrypt(struct s_cardsystem *);
void reader_griffin(struct s_cardsystem *);
void reader_dgcrypt(struct s_cardsystem *);

#endif
