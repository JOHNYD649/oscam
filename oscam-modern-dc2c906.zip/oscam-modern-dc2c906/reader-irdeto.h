#ifndef READER_IRDETO_H_
#define READER_IRDETO_H_

void irdeto_add_emm_header(EMM_PACKET *ep);

#endif
